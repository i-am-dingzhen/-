﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 管理员 : Form
    {
        public 管理员()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            图书管理 f2 = new 图书管理();
            f2.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            用户管理 f2 = new 用户管理();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            罚单管理 f2 = new 罚单管理();
            f2.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            借阅查询 f2 = new 借阅查询 ();
            f2.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            申诉管理 f2 = new 申诉管理();
            f2.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            还书查询 f2 = new 还书查询();
            f2.ShowDialog();
        }
    }
}
