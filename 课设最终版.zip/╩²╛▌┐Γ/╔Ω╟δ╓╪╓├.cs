﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 图书馆系统
{
    public partial class 申请重置 : Form
    {
        public 申请重置()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认提交吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                SqlConnection con = new SqlConnection(str);
                con.Open();
                string selectsql21 = "select * from login where username='" + textBox1.Text + "'";
                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                cmd21.CommandType = CommandType.Text;
                SqlDataReader sdr21;
                sdr21 = cmd21.ExecuteReader();
                if (sdr21.Read())
                {
                    SqlConnection conn11 = new SqlConnection(str);
                    conn11.Open();
                    string selectsql1 = "select * from ss where username = '" + textBox1.Text + "'";
                    SqlCommand cmd11 = new SqlCommand(selectsql1, conn11);
                    cmd11.CommandType = CommandType.Text;
                    SqlDataReader sdr11;
                    sdr11 = cmd11.ExecuteReader();
                    if (sdr11.Read())
                    {
                        MessageBox.Show("已申请！");
                    }

                    else
                    {
                        SqlConnection conn340 = new SqlConnection(str);//实例化cnn对象
                        conn340.Open();//打开
                        string selectsq340 = "select * from ss";
                        SqlDataAdapter Adpt = new SqlDataAdapter(selectsq340, conn340);
                        DataSet ds = new DataSet();
                        Adpt.Fill(ds);
                        int n = ds.Tables[0].Rows.Count;
                        conn340.Close();
                        n += 1;
                        string n1 = Convert.ToString(n);

                        SqlConnection con1 = new SqlConnection(str);
                        con1.Open();
                        string usetime = DateTime.Now.ToString();
                        string selectsql211 = "insert into ss values('" + usetime + "','" + textBox1.Text + "',0,'" + n1 + "')";
                        SqlCommand cmd211 = new SqlCommand(selectsql211, con1);
                        cmd211.CommandType = CommandType.Text;
                        SqlDataReader sdr211;
                        sdr211 = cmd211.ExecuteReader();
                        con1.Close();
                        MessageBox.Show("申请成功");
                    }


                    this.Close();
                }
                else
                {
                    MessageBox.Show("找不到该账户");
                }
                con.Close();
            }
            else
            {
                f2.Close();
            }
        }
    }
}
