﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 图书馆系统
{

    
    public partial class 用户还书 : Form
    {
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        string yh = WindowsFormsApp2.Form1.msg;
        public 用户还书()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from js where username='"+yh+"'", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();

            SqlConnection con = new SqlConnection(str);
            con.Open();

            string selectsql21 = "Select count(*) as s  from js where username='" + yh + "'";
            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
            cmd21.CommandType = CommandType.Text;
            SqlDataReader sdr21;
            sdr21 = cmd21.ExecuteReader();
            sdr21.Read();
            int ss = Convert.ToInt32(sdr21["s"]);
            con.Close();//完成book更新
            label2.Text = "共查询到：" + ss + "条结果";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认还书吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                string str4 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                SqlConnection conn4 = new SqlConnection(str4);
                conn4.Open();
                if (dataGridView1.SelectedRows.Count != 1) return;
                if (dataGridView1.CurrentRow == null) return;
                // string bd = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                DataRowView row1 = dataGridView1.CurrentRow.DataBoundItem as DataRowView;
                if (row1["id"] == null) return;//可以进行快速监视
                string bd1 = Convert.ToString(row1["id"]);
                string mid = " ";
                string text = bd1.Substring(0, bd1.IndexOf(mid));
                string vis = Convert.ToString(row1["flag"]);
                if (vis == "已归还")
                {
                    MessageBox.Show("已归还！");
                }
                else
                {
                    string tm = Convert.ToString(row1["time"]);
                    string usetime = DateTime.Now.ToString();
                    var t1 = Convert.ToDateTime(tm);
                    var t2 = Convert.ToDateTime(usetime);
                    TimeSpan ts = t2 - t1;
                    if (ts.Days >= 5)
                    {
                        SqlConnection con7 = new SqlConnection(str);
                        con7.Open();

                        string selectsql217 = "select * from fadan where username ='" + yh + "' and flag='未处理'";
                        SqlCommand cmd217 = new SqlCommand(selectsql217, con7);
                        cmd217.CommandType = CommandType.Text;
                        SqlDataReader sdr217;
                        sdr217 = cmd217.ExecuteReader();
                        if (sdr217.Read())
                        {

                        }
                        else
                        {
                            SqlConnection conn116 = new SqlConnection(str);
                            conn116.Open();
                            string selectsql16 = "update login set flag = 1 where username  ='" + yh + " '";
                            SqlCommand cmd116 = new SqlCommand(selectsql16, conn116);
                            cmd116.CommandType = CommandType.Text;
                            SqlDataReader sdr116;
                            sdr116 = cmd116.ExecuteReader();
                            conn116.Close();


                            SqlConnection conn340 = new SqlConnection(str);//实例化cnn对象
                            conn340.Open();//打开
                            string selectsq340 = "select * from fadan";
                            SqlDataAdapter Adpt = new SqlDataAdapter(selectsq340, conn340);
                            DataSet ds = new DataSet();
                            Adpt.Fill(ds);
                            int n = ds.Tables[0].Rows.Count;
                            conn340.Close();
                            n += 1;
                            string n1 = Convert.ToString(n);

                            string app1 = @"书号：" + text + "还书超时";

                            string usetime2 = DateTime.Now.ToString();
                            string str349 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                            SqlConnection conn349 = new SqlConnection(str349);//实例化cnn对象
                            conn349.Open();//打开
                            string selectsq349 = "insert into fadan values ('" + n1 + "','" + yh + "','" + usetime + "','" + app1 + "','未处理',0)";
                            SqlCommand cmd349 = new SqlCommand(selectsq349, conn349);
                            cmd349.CommandType = CommandType.Text;
                            SqlDataReader sdr349;
                            sdr349 = cmd349.ExecuteReader();
                            conn349.Close();



                        }
                        MessageBox.Show("还书超时，请至柜台还书");
                    }
                    else
                    {
                        SqlConnection con = new SqlConnection(str);
                        con.Open();

                        string selectsql21 = "select * from book where id  = '" + bd1 + "'";
                        SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                        cmd21.CommandType = CommandType.Text;
                        SqlDataReader sdr21;
                        sdr21 = cmd21.ExecuteReader();
                        sdr21.Read();
                        int nn = Convert.ToInt32(sdr21["nnum"]);
                        con.Close();




                        SqlConnection con1 = new SqlConnection(str);
                        con1.Open();
                        nn += 1;
                        string selectsql211 = "update book set nnum = " + nn + " where id = '" + bd1 + "'";
                        SqlCommand cmd211 = new SqlCommand(selectsql211, con1);
                        cmd211.CommandType = CommandType.Text;
                        SqlDataReader sdr211;
                        sdr211 = cmd211.ExecuteReader();
                        con1.Close();//完成book更新


                        //借书
                        SqlConnection conn1211 = new SqlConnection(str);

                        conn1211.Open();
                        string selectsql = "insert into hs values('" + yh + "','" + bd1 + "','" + usetime + "')";
                        SqlCommand cmd1211 = new SqlCommand(selectsql, conn1211);
                        cmd1211.CommandType = CommandType.Text;
                        SqlDataReader sdr1211;
                        sdr1211 = cmd1211.ExecuteReader();
                        conn1211.Close();

                        SqlConnection conn116 = new SqlConnection(str);
                        conn116.Open();
                        string selectsql16 = "select * from login where username = '" + yh + "'";
                        SqlCommand cmd116 = new SqlCommand(selectsql16, conn116);
                        cmd116.CommandType = CommandType.Text;
                        SqlDataReader sdr1167;
                        sdr1167 = cmd116.ExecuteReader();
                        sdr1167.Read();
                        int op = Convert.ToInt32(sdr1167["jieshu"]);
                        conn116.Close();



                        SqlConnection conn3 = new SqlConnection(str);
                        op -= 1;
                        conn3.Open();
                        string selectsql3 = "update login set jieshu = " + op + " where username = '" + yh + "'";
                        SqlCommand cmd3 = new SqlCommand(selectsql3, conn3);
                        cmd3.CommandType = CommandType.Text;
                        SqlDataReader sdr3;
                        sdr3 = cmd3.ExecuteReader();
                        conn3.Close();


                        SqlConnection conn9 = new SqlConnection(str);
                        conn9.Open();
                        string selectsql9 = "update  js set flag = '已归还' where flag='未归还' and  id='" + bd1 + "' and username='" + yh + "'";
                        SqlCommand cmd9 = new SqlCommand(selectsql9, conn9);
                        cmd9.CommandType = CommandType.Text;
                        SqlDataReader sdr9;
                        sdr9 = cmd9.ExecuteReader();
                        conn9.Close();


                        MessageBox.Show("用户 " + yh + " 还书成功,书号：" + bd1 + " 剩余数量：" + nn);
                        string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                        SqlConnection conn1523 = new SqlConnection(str1523);
                        conn1523.Open();

                        SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from js where username='" + yh + "'", conn1523);
                        DataSet dds1523 = new DataSet();
                        sqlDap323.Fill(dds1523);
                        DataTable _table123 = dds1523.Tables[0];
                        int count123 = _table123.Rows.Count;
                        dataGridView1.DataSource = _table123;
                        conn1523.Close();
                    }


                }
            }
            else
            {
                f2.Close();
            }
        }
        string  flag = "";
        private void button2_Click(object sender, EventArgs e)
        {

            if (radioButton1.Checked) flag = "已归还";//管理员
            if (radioButton2.Checked) flag = "未归还";   //学生
            SqlConnection conn = new SqlConnection(str);
            conn.Open();

            SqlDataAdapter sqlDap = new SqlDataAdapter("Select * from js where id like '%" + textBox1.Text + "%' and username = '"+yh +"' and flag='"+flag+"' order by id", conn);
            DataSet dds = new DataSet();
            sqlDap.Fill(dds);
            DataTable _table = dds.Tables[0];
            int count = _table.Rows.Count;
            dataGridView1.DataSource = _table;
            conn.Close();


            SqlConnection con = new SqlConnection(str);
            con.Open();

            string selectsql21 = "Select count(*) as s from js where id like '%" + textBox1.Text + "%' and username ='"+yh+ "'and flag='"+flag+"'";
            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
            cmd21.CommandType = CommandType.Text;
            SqlDataReader sdr21;
            sdr21 = cmd21.ExecuteReader();
            sdr21.Read();
            int ss = Convert.ToInt32(sdr21["s"]);
            con.Close();//完成book更新
            label2.Text = "共查询到：" + ss + "条结果";
            flag = "";
        }
    }
}
