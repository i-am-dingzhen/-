﻿using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using 图书馆系统;
namespace WindowsFormsApp2

{

    public partial class Form1 : Form
    {
        public Form1()
        {

            InitializeComponent();
        }
        public static string msg = "";//用户名msg
        public static int dlflag = 2;   //学生2  管理员1
        private void button2_Click(object sender, EventArgs e)
        {
            用户注册 f2 = new 用户注册();
            f2.ShowDialog();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text != "" && textBox2.Text != "")
            {

                if (radioButton1.Checked) dlflag = 1;//管理员
                if (radioButton2.Checked) dlflag = 2;   //学生



                if (dlflag == 2)
                {
                    //数据库连接字符串
                    string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn = new SqlConnection(str);//实例化sql连接对象
                    conn.Open();
                    //写sqlserver语句
                    string selectsql = "Select * from login where username = '" + textBox1.Text + "' and password='" + textBox2.Text + "'";
                    SqlCommand cmd = new SqlCommand(selectsql, conn);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                    cmd.CommandType = CommandType.Text;
                    //cmd执行的sql是你赋给CommandText的值里写出的sql语句，
                    //CommandType是SqlCommand对象的一个属性，CommandType是一个枚举类型，用于指定执行动作的形式，它告诉接下来执行的是一个文本(text)。
                    //有三个值：text、StoredProcedure、TableDirect，用于表示SqlCommand对象CommandType的执行形式。

                    SqlDataReader sdr;//声明对象 
                    sdr = cmd.ExecuteReader();  //读cmd取到的text文本
                    if (sdr.Read())//读到存在账号密码
                    {


                        MessageBox.Show("用户登陆成功");
                        msg = textBox1.Text;
                        用户 f2 = new 用户();
                        f2.ShowDialog();



                    }
                    else
                    {
                        label4.Visible = true;
                        label4.Text = "用户登陆失败!"; //label3在界面没有显示，因为我设置了显示为一个空格，label控件用以显示提示登录信息

                        textBox2.Text = "";

                    }
                    conn.Close();//关闭对象
                }
                if (dlflag == 1)
                {
                    string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn = new SqlConnection(str);
                    conn.Open();
                    string selectsql = "Select * from loginad where username = '" + textBox1.Text + "' and password='" + textBox2.Text + "'";
                    SqlCommand cmd = new SqlCommand(selectsql, conn);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                    cmd.CommandType = CommandType.Text;
                    SqlDataReader sdr;
                    sdr = cmd.ExecuteReader();
                    if (sdr.Read())
                    {
                        MessageBox.Show("管理员登陆成功");
                        管理员 f2 = new 管理员();
                        f2.ShowDialog();

                    }
                    else
                    {
                        label4.Visible = true;
                        label4.Text = "登陆管理员失败!";

                        textBox2.Text = "";
                    }
                    conn.Close();
                }
            }
            else label4.Text = "用户名或密码为空!";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            账户申诉 f2 = new 账户申诉();
            f2.ShowDialog();
        }
    }
}
