﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 个人信息 : Form
    {
        string yh = WindowsFormsApp2.Form1.msg;
        string str= @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        public 个人信息()
        {
            InitializeComponent();
            SqlConnection conn11 = new SqlConnection(str);
            conn11.Open();
            string selectsql1 = "select * from login where username = '" + yh + "'";
            SqlCommand cmd11 = new SqlCommand(selectsql1, conn11);
            cmd11.CommandType = CommandType.Text;
            SqlDataReader sdr11;
            sdr11 = cmd11.ExecuteReader();
            sdr11.Read();
            int op = Convert.ToInt32(sdr11["age"]);
            string op1 = Convert.ToString(op);
            label11.Text = op1;
            string sex= Convert.ToString(sdr11["sex"]);
            label12.Text = sex;
            int pnum = Convert.ToInt32(sdr11["pnum"]);
            string pnum1 = Convert.ToString(pnum);
            label13.Text = pnum1;

            int flag = Convert.ToInt32(sdr11["flag"]);
            if (flag == 0)
            {
                string p = "可借书";
                label14.Text = p;

            }
            else
            {
                string p = "不可借书";
                label14.Text = p;
            }
            string name = Convert.ToString(sdr11["username"]);
            label15.Text = name;

        }
        
        private void 个人信息_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)

        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {

                SqlConnection con = new SqlConnection(str);
                con.Open();

                string selectsql21 = "update login set password = '" + textBox1.Text + "' where username = '" + yh + "'";
                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                cmd21.CommandType = CommandType.Text;
                SqlDataReader sdr21;
                sdr21 = cmd21.ExecuteReader();
                con.Close();//完成book更新
                MessageBox.Show("修改成功！");
            }
            else
            {
                f2.Close();
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(str);
                con.Open();

                string selectsql21 = "update login set age = " + textBox2.Text + " where username = '" + yh + "'";
                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                cmd21.CommandType = CommandType.Text;
                SqlDataReader sdr21;
                sdr21 = cmd21.ExecuteReader();
                con.Close();//完成book更新
                MessageBox.Show("修改成功！");
            }
            else
            {
                f2.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(str);
                con.Open();

                string selectsql21 = "update login set sex = '" + textBox3.Text + "' where username = '" + yh + "'";
                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                cmd21.CommandType = CommandType.Text;
                SqlDataReader sdr21;
                sdr21 = cmd21.ExecuteReader();
                con.Close();//完成book更新
                MessageBox.Show("修改成功！");
            }
            else
            {
                f2.Close();
            }

        }

        private void button5_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                SqlConnection con = new SqlConnection(str);
                con.Open();

                string selectsql21 = "update login set pnum = " + textBox4.Text + " where username = '" + yh + "'";
                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                cmd21.CommandType = CommandType.Text;
                SqlDataReader sdr21;
                sdr21 = cmd21.ExecuteReader();
                con.Close();//完成book更新
                MessageBox.Show("修改成功！");
            }
            else
            {
                f2.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            罚单查看 f2 = new 罚单查看();
            f2.ShowDialog();
        }
    }
}
