﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 图书馆系统
{
    public partial class 借阅查看 : Form
    {
        string yh = WindowsFormsApp2.Form1.msg;
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        public 借阅查看()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("select a.id as id , a.time as time  ,a.username as username ,b.bname as bname, b.btype as btype,b. cb as cb , a.flag as flag from js as a left join book as b on  a.id=b.id where a.username ='"+yh+"'", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();

            SqlConnection con = new SqlConnection(str);
            con.Open();

            string selectsql21 = "Select count(*) as s  from js where username='"+yh+"'";
            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
            cmd21.CommandType = CommandType.Text;
            SqlDataReader sdr21;
            sdr21 = cmd21.ExecuteReader();
            sdr21.Read();
            int ss = Convert.ToInt32(sdr21["s"]);
            con.Close();//完成book更新
            label1.Text = "共查询到：" + ss + "条结果";
        }
        string flag = "";
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked) flag = "已归还";//管理员
            if (radioButton2.Checked) flag = "未归还";   //学生

            string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();

            SqlDataAdapter sqlDap = new SqlDataAdapter("select a.id as id , a.time as time  ,a.username as username ,b.bname as bname, b.btype as btype,b. cb as cb,a.flag as flag from js as a left join book as b on  a.id=b.id where a.id like '%" + textBox1.Text + "%' and a.username like '%" + yh + "%' and a.time like '%" + textBox5.Text + "%' and b.cb like '%" + textBox4.Text + "%' and b.btype like '%" + textBox3.Text + "%' and a.flag like '%" + flag + "%' and b.bname like '%"+ textBox2.Text+"%'", conn);
            DataSet dds = new DataSet();
            sqlDap.Fill(dds);
            DataTable _table = dds.Tables[0];
            int count = _table.Rows.Count;
            dataGridView1.DataSource = _table;


            SqlConnection con = new SqlConnection(str);
            con.Open();

            string selectsql21 = "select count(*) as s from js as a left join book as b on  a.id=b.id where a.id like '%" + textBox1.Text + "%' and a.username like '%" + yh + "%' and a.time like '%" + textBox5.Text + "%' and b.cb like '%" + textBox4.Text + "%' and b.btype like '%" + textBox3.Text + "%' and a.flag like '%" + flag + "%' and b.bname like '%" + textBox2.Text + "%'";
            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
            cmd21.CommandType = CommandType.Text;
            SqlDataReader sdr21;
            sdr21 = cmd21.ExecuteReader();
            sdr21.Read();
            int ss = Convert.ToInt32(sdr21["s"]);
            con.Close();//完成book更新
            label1.Text = "共查询到：" + ss + "条结果";




            flag = "";

        }
    }
}
