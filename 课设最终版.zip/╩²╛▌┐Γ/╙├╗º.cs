﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp2;
namespace 图书馆系统
{
    public partial class 用户 : Form
    {
        string yh = WindowsFormsApp2.Form1.msg;
        public static string ltype = "";
        public 用户()
        {
            bool vis = true;
            InitializeComponent();
            string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn116 = new SqlConnection(str);
            conn116.Open();
            string selectsql16 = " select  time from js where username ='" + yh + "' and flag='未归还' ";
            SqlCommand cmd116 = new SqlCommand(selectsql16, conn116);
            cmd116.CommandType = CommandType.Text;
            SqlDataReader sdr116;
            sdr116 = cmd116.ExecuteReader();
            if (sdr116.Read())
            {
                do
                {
                    string tm = Convert.ToString(sdr116["time"]);
                    string usetime = DateTime.Now.ToString();
                    var t1 = Convert.ToDateTime(tm);
                    var t2 = Convert.ToDateTime(usetime);
                    TimeSpan ts = t2 - t1;
                    if (ts.Days >= 5)
                    {
                        vis = false;
                        break;
                    }
                } while (sdr116.Read());
            }
            if (vis == false)
            {
                SqlConnection conn16 = new SqlConnection(str);
                conn16.Open();
                string selectsql6 = "update login set flag = 1 where username ='" + yh + " '";
                SqlCommand cmd16 = new SqlCommand(selectsql6, conn16);
                cmd16.CommandType = CommandType.Text;
                SqlDataReader sdr16;
                sdr16 = cmd16.ExecuteReader();
                conn16.Close();
            }
            conn116.Close();


            SqlConnection conn160 = new SqlConnection(str);
            conn160.Open();
            string selectsql60 = " select  * from login where username ='" + yh + "' ";
            SqlCommand cmd160 = new SqlCommand(selectsql60, conn160);
            cmd160.CommandType = CommandType.Text;
            SqlDataReader sdr160;
            sdr160 = cmd160.ExecuteReader();
            sdr160.Read();
            ltype = Convert.ToString(sdr160["ltype"]);
            int js= Convert.ToInt32(sdr160["jieshu"]);
            int f= Convert.ToInt32(sdr160["flag"]);
            string pp = "";
            string mid1 = " ";
            string text = ltype.Substring(0, ltype.IndexOf(mid1));
            ltype = text;
            if (f == 1)
            {
                pp = "不可借书";
                label1.Text = "尊敬的" + text + "用户，您当前" + pp;
            }
            else
            {
                if (text == "普通")
                {
                    int mid=(5 - js);
                    string opop = Convert.ToString(mid);
                    label1.Text = "尊敬的" + text + "用户，您当前可借" + opop+"本书";
                }
                else
                {
                    int mid = (8 - js);
                    string opop = Convert.ToString(mid);
                    label1.Text = "尊敬的" + text + "用户，您当前可借" + opop + "本书";
                }

            }
            conn160.Close();
            
        }

        private void 用户_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            用户查书cs f2 = new 用户查书cs();
            f2.ShowDialog();

              
        }

        private void button2_Click(object sender, EventArgs e)
        {
            用户借阅 f2 = new 用户借阅();
            f2.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            用户还书 f2 = new 用户还书();
            f2.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            个人信息 f2 = new 个人信息();
            f2.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            还书查看 f2 = new 还书查看();
            f2.ShowDialog();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            借阅查看 f2 = new 借阅查看();
            f2.ShowDialog();
        }
    }
}
