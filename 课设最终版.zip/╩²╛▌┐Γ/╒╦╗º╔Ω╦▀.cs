﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 账户申诉 : Form
    {
        
        public 账户申诉()
        {
            InitializeComponent();
        }
        public static string yy = "";
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text !="" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "")
            {
                SqlConnection con = new SqlConnection(str);
                con.Open();
                string selectsql21 = "select * from login where username='"+ textBox1.Text+"' and age="+textBox2.Text+" and sex='"+ textBox3.Text+"' and pnum="+ textBox4.Text+"";
                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                cmd21.CommandType = CommandType.Text;
                SqlDataReader sdr21;
                sdr21 = cmd21.ExecuteReader();
                if (sdr21.Read())
                {
                    yy = textBox1.Text;
                    修改密码 f2 = new 修改密码();
                    f2.ShowDialog();

                }
                else
                {
                    MessageBox.Show("输入错误！");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            申请重置 f2 = new 申请重置();
            f2.ShowDialog();
        }
    }
}
