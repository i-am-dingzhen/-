﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 修改密码 : Form
    {
        public 修改密码()
        {
            InitializeComponent();
        }
        string yy = 图书馆系统.账户申诉.yy;
        private void button1_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (textBox1.Text == textBox2.Text && textBox1.Text != "")
                {
                    string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection con = new SqlConnection(str);
                    con.Open();

                    string selectsql21 = "update login set password = " + textBox1.Text + " where username = '" + yy + "'";
                    SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                    cmd21.CommandType = CommandType.Text;
                    SqlDataReader sdr21;
                    sdr21 = cmd21.ExecuteReader();
                    con.Close();
                    MessageBox.Show("修改完成！");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("输入不一致！");
                }
            }
            else
            {
                f2.Close();
            }
        }
    }
}
