﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 图书馆系统
{
    public partial class 用户管理 : Form
    {
        public 用户管理()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from login", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }
        private void fun()
        {
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from login", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }
        private bool fun1(string a)
        {
            if (a == "") return false;
            SqlConnection conn1 = new SqlConnection(str);//实例化sql连接对象
            conn1.Open();
            //写sqlserver语句
            string selectsql1 = "select * from login where username ='" + a + "'";
            SqlCommand cmd1 = new SqlCommand(selectsql1, conn1);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
            cmd1.CommandType = CommandType.Text;
            SqlDataReader sdr1;//声明对象 
            sdr1 = cmd1.ExecuteReader();
            if (sdr1.Read()) return true;
            else return false;

        }
        public static string sex = "";
        public static string flag = "";
        public static string ltype = "";
        bool r1 = false;
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                sex = "男"; r1 = true;
            }//管理员
            if (radioButton2.Checked) sex = "女";   //学生
            if (radioButton3.Checked) flag = "0";//管理员
            if (radioButton4.Checked) flag = "1";   //学生
            if (radioButton5.Checked) ltype  = "普通";//管理员
            if (radioButton6.Checked) ltype  = "贵宾";   //学生

            bool vis = true;
            if (textBox2.Text != "" )
            {
                int mid = 0;
                
                try
                {
                    mid = Convert.ToInt32(textBox2.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("年龄，请输入数字");
                    vis = false;
                }
            }
            if (textBox4.Text != "")
            {
                int mid = 0;

                try
                {
                    mid = Convert.ToInt32(textBox4.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("电话，请输入数字");
                    vis = false;
                }
            }
            if (vis == true)
            {
                SqlConnection conn = new SqlConnection(str);
                conn.Open();

                SqlDataAdapter sqlDap = new SqlDataAdapter("Select * from login where username like '%" + textBox1.Text + "%' and age like '%" + textBox2.Text + "%'  and pnum like '%" + textBox4.Text + "%'  and sex like '%" + sex + "%' and flag like '%" + flag + "%'and ltype like '%" + ltype + "%' order by username", conn);
                DataSet dds = new DataSet();
                sqlDap.Fill(dds);
                DataTable _table = dds.Tables[0];
                int count = _table.Rows.Count;
                dataGridView1.DataSource = _table;
                conn.Close();
                sex = "";
                flag = "";
                ltype = "";

            }
           
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                int mid = 0;
                bool vis = true;
                try
                {
                    mid = Convert.ToInt32(textBox5.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("年龄，请输入数字");
                    vis = false;
                }
                if (vis)
                {
                    if (fun1(textBox3.Text))
                    {
                        SqlConnection con = new SqlConnection(str);
                        con.Open();

                        string selectsql21 = "update login set age  = '" + textBox5.Text + "' where username = '" + textBox3.Text + "'";
                        SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                        cmd21.CommandType = CommandType.Text;
                        SqlDataReader sdr21;
                        sdr21 = cmd21.ExecuteReader();
                        con.Close();
                        fun();
                        MessageBox.Show("修改成功！");

                    }
                    else
                    {
                        MessageBox.Show("用户不存在");
                    }
                }
            }
            else
            {
                f2.Close();
            }
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                int mid = 0;
                bool vis = true;
                try
                {
                    mid = Convert.ToInt32(textBox6.Text);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("电话，请输入数字");
                    vis = false;
                }
                if (vis)
                {
                    if (fun1(textBox3.Text))
                    {
                        SqlConnection con = new SqlConnection(str);
                        con.Open();

                        string selectsql21 = "update login set pnum  = '" + textBox6.Text + "' where username = '" + textBox3.Text + "'";
                        SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                        cmd21.CommandType = CommandType.Text;
                        SqlDataReader sdr21;
                        sdr21 = cmd21.ExecuteReader();
                        con.Close();
                        fun();
                        MessageBox.Show("修改成功！");
                    }
                    else
                    {
                        MessageBox.Show("用户不存在");
                    }
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (radioButton7.Checked) flag = "女";//管理员
                if (radioButton8.Checked) flag = "男";   //学生
                if (flag == "")
                {
                    MessageBox.Show("请选择性别");
                }
                else
                {
                    if (fun1(textBox3.Text))
                    {
                        SqlConnection con = new SqlConnection(str);
                        con.Open();

                        string selectsql21 = "update login set sex  =' " + flag + "' where username = '" + textBox3.Text + "'";
                        SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                        cmd21.CommandType = CommandType.Text;
                        SqlDataReader sdr21;
                        sdr21 = cmd21.ExecuteReader();
                        con.Close();
                        fun();
                        MessageBox.Show("修改成功！");
                        fun();
                    }
                    else
                    {
                        MessageBox.Show("用户不存在");
                    }
                    flag = "";
                }
            }
            else
            {
                f2.Close();
            }
           
        }

        private void button5_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (radioButton9.Checked) flag = "贵宾";//管理员
                if (radioButton10.Checked) flag = "普通";   //学生
                if (flag == "")
                {
                    MessageBox.Show("请选择等级");
                }
                else
                {
                    if (fun1(textBox3.Text))
                    {
                        SqlConnection con = new SqlConnection(str);
                        con.Open();

                        string selectsql21 = "update login set ltype  = '" + flag + " ' where username = '" + textBox3.Text + "'";
                        SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                        cmd21.CommandType = CommandType.Text;
                        SqlDataReader sdr21;
                        sdr21 = cmd21.ExecuteReader();
                        con.Close();
                        fun();
                        MessageBox.Show("修改成功！");
                        fun();
                    }
                    else
                    {
                        MessageBox.Show("用户不存在");
                    }
                    flag = "";
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            flag = "";
            确认 f2 = new 确认();
            string mid3 = "确认添加吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (radioButton11.Checked) flag = "男";//管理员
                if (radioButton12.Checked) flag = "女";   //学生
                if (flag != "" && textBox7.Text != "" && textBox8.Text != "" && textBox9.Text != "" && textBox10.Text != "")
                {
                    bool vis = true;
                    int mid = 0;

                    try
                    {
                        mid = Convert.ToInt32(textBox8.Text);
                        mid = Convert.ToInt32(textBox9.Text);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("年龄或电话，请输入数字");
                        vis = false;
                    }
                    if (vis)
                    {

                        SqlConnection conn = new SqlConnection(str);//实例化sql连接对象
                        conn.Open();
                        //写sqlserver语句
                        string selectsql = "Select * from login where username = '" + textBox7.Text + "'";
                        SqlCommand cmd = new SqlCommand(selectsql, conn);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                        cmd.CommandType = CommandType.Text;
                        SqlDataReader sdr;//声明对象 
                        sdr = cmd.ExecuteReader();
                        if (sdr.Read())
                        {

                            MessageBox.Show("用户名已存在！");
                        }
                        else
                        {
                            SqlConnection conn1 = new SqlConnection(str);//实例化sql连接对象
                            conn1.Open();
                            //写sqlserver语句
                            string selectsql1 = "insert into login values ('" + textBox7.Text + "','" + textBox10.Text + "'," + textBox8.Text + ",'" + flag + "'," + textBox9.Text + ",0,0,'普通')";
                            SqlCommand cmd1 = new SqlCommand(selectsql1, conn1);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                            cmd1.CommandType = CommandType.Text;
                            SqlDataReader sdr1;//声明对象 
                            sdr1 = cmd1.ExecuteReader();  //读cmd取到的text文本
                            conn1.Close();
                            MessageBox.Show("注册成功！");
                            fun();
                        }

                    }

                }
                else
                {
                    MessageBox.Show("请将信息填写完整！");
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认删除吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (fun1(textBox11.Text))
                {
                    SqlConnection con = new SqlConnection(str);
                    con.Open();

                    string selectsql21 = "delete from login   where username = '" + textBox11.Text + "'";
                    SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                    cmd21.CommandType = CommandType.Text;
                    SqlDataReader sdr21;
                    sdr21 = cmd21.ExecuteReader();
                    con.Close();
                    fun();
                    MessageBox.Show("删除成功！");
                }
                else
                {
                    MessageBox.Show("用户不存在");
                }
            }
            else
            {
                f2.Close();
            }
        }
    }
}
