﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 用户借阅 : Form
    {
        string l = 图书馆系统.用户.ltype;
        string yh = WindowsFormsApp2.Form1.msg;
        public 用户借阅()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from book", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }

        private void 用户借阅_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认借书吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                string str4 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                SqlConnection conn4 = new SqlConnection(str4);
                conn4.Open();
                if (dataGridView1.SelectedRows.Count != 1) return;
                if (dataGridView1.CurrentRow == null) return;
                // string bd = dataGridView1.CurrentRow.Cells[2].Value.ToString();

                DataRowView row1 = dataGridView1.CurrentRow.DataBoundItem as DataRowView;
                if (row1["id"] == null) return;//可以进行快速监视
                string bd1 = Convert.ToString(row1["id"]);
                int nn = Convert.ToInt32(row1["nnum"]);
                if (nn <= 0)
                {
                    MessageBox.Show("库存不足！");
                }
                else
                {
                    string selectsql4 = "Select * from js where username = '" + yh + "' and id='" + bd1 + "'";
                    SqlCommand cmd4 = new SqlCommand(selectsql4, conn4);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                    cmd4.CommandType = CommandType.Text;
                    SqlDataReader sdr4;
                    sdr4 = cmd4.ExecuteReader();
                    if (sdr4.Read())//查询到借书信息
                    {
                        MessageBox.Show("你已经借阅了本书");
                    }
                    else
                    {
                        SqlConnection conn11 = new SqlConnection(str4);
                        conn11.Open();
                        string selectsql1 = "select * from login where username = '" + yh + "'";
                        SqlCommand cmd11 = new SqlCommand(selectsql1, conn11);
                        cmd11.CommandType = CommandType.Text;
                        SqlDataReader sdr11;
                        sdr11 = cmd11.ExecuteReader();
                        sdr11.Read();
                        int op = Convert.ToInt32(sdr11["jieshu"]);
                        int flag = Convert.ToInt32(sdr11["flag"]);
                        conn11.Close();
                        int maxa = 0;
                        if (l == "普通") maxa = 5;
                        else maxa = 8;
                        if (op == maxa)
                        {
                            MessageBox.Show("你已经无法借书！");
                        }

                        else
                        {
                            if (flag == 1)
                            {
                                MessageBox.Show("你有违规未处理，无法借书！");

                            }
                            else
                            {
                                string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                                SqlConnection con = new SqlConnection(str);
                                con.Open();
                                nn -= 1;
                                string selectsql21 = "update book set nnum = " + nn + " where id = '" + bd1 + "'";
                                SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                                cmd21.CommandType = CommandType.Text;
                                SqlDataReader sdr21;
                                sdr21 = cmd21.ExecuteReader();
                                con.Close();//完成book更新

                                //jieshu
                                string str12 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                                SqlConnection conn12 = new SqlConnection(str12);
                                string usetime = DateTime.Now.ToString();
                                conn12.Open();
                                string selectsql12 = "insert into js values('" + yh + "','" + bd1 + "','" + usetime + "','未归还')";
                                SqlCommand cmd12 = new SqlCommand(selectsql12, conn12);
                                cmd12.CommandType = CommandType.Text;
                                SqlDataReader sdr12;
                                sdr12 = cmd12.ExecuteReader();
                                conn12.Close();

                                string str1211 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                                SqlConnection conn1211 = new SqlConnection(str1211);
                                op += 1;
                                conn1211.Open();
                                string selectsql1211 = "update login set jieshu = " + op + " where username = '" + yh + "'";
                                SqlCommand cmd1211 = new SqlCommand(selectsql1211, conn1211);
                                cmd12.CommandType = CommandType.Text;
                                SqlDataReader sdr1211;
                                sdr1211 = cmd1211.ExecuteReader();
                                conn1211.Close();
                                MessageBox.Show("用户 " + yh + " 借阅成功,书号：" + bd1 + " 剩余数量：" + nn);


                                string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                                SqlConnection conn1523 = new SqlConnection(str1523);
                                conn1523.Open();

                                SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from book", conn1523);
                                DataSet dds1523 = new DataSet();
                                sqlDap323.Fill(dds1523);
                                DataTable _table123 = dds1523.Tables[0];
                                int count123 = _table123.Rows.Count;
                                dataGridView1.DataSource = _table123;
                                conn1523.Close();
                            }


                        }
                        //kaishi 

                    }


                }
                conn4.Close();
            }
            else
            {
                f2.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();

            SqlDataAdapter sqlDap = new SqlDataAdapter("Select * from book where id like '%" + textBox1.Text + "%' and bname like '%" + textBox2.Text + "%'  and btype like '%" + textBox3.Text + "%'  and cb like '%" + textBox4.Text + "%'order by id", conn);
            DataSet dds = new DataSet();
            sqlDap.Fill(dds);
            DataTable _table = dds.Tables[0];
            int count = _table.Rows.Count;
            dataGridView1.DataSource = _table;
            conn.Close();

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }
    }
}
