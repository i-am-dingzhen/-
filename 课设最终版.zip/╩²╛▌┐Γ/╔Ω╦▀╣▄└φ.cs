﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 申诉管理 : Form
    {
        public 申诉管理()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from ss", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        private void 审核通过_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1) return;
            if (dataGridView1.CurrentRow == null) return;
            // string bd = dataGridView1.CurrentRow.Cells[2].Value.ToString();

            DataRowView row1 = dataGridView1.CurrentRow.DataBoundItem as DataRowView;
            if (row1["id"] == null) return;//可以进行快速监视
            string bd1 = Convert.ToString (row1["username"]);
            int flag1 = Convert.ToInt32 (row1["flag"]);
            string id1 = Convert.ToString(row1["id"]);
            确认 f2 = new 确认();
            string mid3 = "确认同意申诉吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (flag1 == 1)
                {

                    MessageBox.Show("已处理，请重选！");
                }
                else
                {
                    SqlConnection conn116 = new SqlConnection(str);
                    conn116.Open();
                    string selectsql16 = "update login set password = '123' where username ='" +  bd1+ " '";
                    SqlCommand cmd116 = new SqlCommand(selectsql16, conn116);
                    cmd116.CommandType = CommandType.Text;
                    SqlDataReader sdr116;
                    sdr116 = cmd116.ExecuteReader();
                    conn116.Close();

                    SqlConnection conn1164 = new SqlConnection(str);
                    conn1164.Open();
                    string selectsql164 = "update ss set flag = 1 where id ='" + id1 + " ' ";
                    SqlCommand cmd1164 = new SqlCommand(selectsql164, conn1164);
                    cmd1164.CommandType = CommandType.Text;
                    SqlDataReader sdr1164;
                    sdr1164 = cmd1164.ExecuteReader();
                    conn1164.Close();

                    MessageBox.Show("处理成功！");

                    string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn1523 = new SqlConnection(str1523);
                    conn1523.Open();

                    SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from ss", conn1523);
                    DataSet dds1523 = new DataSet();
                    sqlDap323.Fill(dds1523);
                    DataTable _table123 = dds1523.Tables[0];
                    int count123 = _table123.Rows.Count;
                    dataGridView1.DataSource = _table123;
                    conn1523.Close();
                }
            }
            else
            {
                f2.Close();
            }
        }
        int flag = 0;
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked) flag = 1;//管理员
            if (radioButton2.Checked) flag = 0;   //学生

            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();
            string sp = Convert.ToString(flag);
            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from ss where flag='"+sp+"' and username like '%"+ textBox1.Text+"%'", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
            flag = 0;
        }
    }
}
