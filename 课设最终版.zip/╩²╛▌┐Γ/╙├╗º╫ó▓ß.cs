﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace 图书馆系统
{
    public partial class 用户注册 : Form
    {
        public 用户注册()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认注册吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                bool vis = true;
                if (textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && textBox5.Text != "")
                {
                    string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn = new SqlConnection(str);//实例化sql连接对象
                    conn.Open();
                    //写sqlserver语句
                    string selectsql = "Select * from login where username = '" + textBox1.Text + "'";
                    SqlCommand cmd = new SqlCommand(selectsql, conn);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                    cmd.CommandType = CommandType.Text;
                    //cmd执行的sql是你赋给CommandText的值里写出的sql语句，
                    //CommandType是SqlCommand对象的一个属性，CommandType是一个枚举类型，用于指定执行动作的形式，它告诉接下来执行的是一个文本(text)。
                    //有三个值：text、StoredProcedure、TableDirect，用于表示SqlCommand对象CommandType的执行形式。

                    SqlDataReader sdr;//声明对象 
                    sdr = cmd.ExecuteReader();  //读cmd取到的text文本
                    int mid;
                    try
                    {
                        mid = Convert.ToInt32(textBox3.Text);
                        mid = Convert.ToInt32(textBox3.Text);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("年龄或电话，请输入数字");
                        vis = false;
                    }

                    if (vis == true)
                    {
                        if (sdr.Read())
                        {

                            MessageBox.Show("用户名已存在！");
                        }
                        else
                        {
                            SqlConnection conn1 = new SqlConnection(str);//实例化sql连接对象
                            conn1.Open();
                            //写sqlserver语句
                            string selectsql1 = "insert into login values ('" + textBox1.Text + "','" + textBox2.Text + "'," + textBox3.Text + ",'" + textBox4.Text + "'," + textBox5.Text + ",0,0,'普通')";
                            SqlCommand cmd1 = new SqlCommand(selectsql1, conn1);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                            cmd1.CommandType = CommandType.Text;
                            SqlDataReader sdr1;//声明对象 
                            sdr1 = cmd1.ExecuteReader();  //读cmd取到的text文本
                            conn1.Close();
                            MessageBox.Show("注册成功！");

                        }

                    }
                    conn.Close();

                }
                else
                {
                    MessageBox.Show("请将信息填写完整！");
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
