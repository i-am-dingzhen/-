﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 罚单管理 : Form
    {
        public 罚单管理()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from fadan", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
            string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection con = new SqlConnection(str);
            con.Open();

            string selectsql21 = "select count(*) as s from fadan";
            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
            cmd21.CommandType = CommandType.Text;
            SqlDataReader sdr21;
            sdr21 = cmd21.ExecuteReader();
            sdr21.Read();
            int ss = Convert.ToInt32(sdr21["s"]);
            con.Close();//完成book更新
            label5.Text = "共查询到：" + ss + "条结果";
        }
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        private void 选择处理_Click(object sender, EventArgs e)
        {
            
            if (dataGridView1.SelectedRows.Count != 1) return;
            if (dataGridView1.CurrentRow == null) return;
            // string bd = dataGridView1.CurrentRow.Cells[2].Value.ToString();

            DataRowView row1 = dataGridView1.CurrentRow.DataBoundItem as DataRowView;
            if (row1["id"] == null) return;//可以进行快速监视
            int bd1 = Convert.ToInt32 (row1["id"]);

            string usid = Convert.ToString(row1["username"]);
            string flag = Convert.ToString(row1["flag"]);
            string flag1 = flag.Substring(0, 3);
            string text1 = Convert.ToString(row1["text"]);
            text1 = text1.Substring(3);
            string mid = "还";
            string text = text1.Substring(0, text1.IndexOf(mid));

            确认 f2 = new 确认();
            string mid3 = "确认处理吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (flag1 == "已处理")
                {

                    MessageBox.Show("已处理，请重选！");
                }
                else
                {
                    string p = "";
                    string str119 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn119 = new SqlConnection(str119);
                    conn119.Open();
                    string selectsql119 = "select * from js where username='" + usid + "' and id ='" + text + "' and flag= '未归还'";
                    SqlCommand cmd119 = new SqlCommand(selectsql119, conn119);
                    SqlDataReader read = cmd119.ExecuteReader();
                    read.Read();
                    string da = read["time"].ToString();
                    string no = DateTime.Now.ToString();
                    var dateTime1 = DateTime.Parse(da);
                    var dateTime2 = DateTime.Parse(no);
                    TimeSpan ts = dateTime2 - dateTime1;
                    int qian = 0;
                    if (ts.Days >= 5 && ts.Days < 10)
                    {
                        p = "用户需缴纳5元罚款。";
                        qian = 5;
                    }
                    else if (ts.Days >= 10 && ts.Days < 15)
                    {
                        p = "用户需缴纳10元罚款。";
                        qian = 10;
                    }
                    else if (ts.Days >= 15)
                    {
                        qian = (ts.Days - 5) * 2;
                        string mid223 = Convert.ToString(qian);
                        p = "用户需缴纳" + mid223 + "元罚款。";

                    }
                    string str11 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn11 = new SqlConnection(str11);
                    conn11.Open();
                    string selectsql11 = "update book set nnum = nnum+1 where id = '" + text + "'";
                    SqlCommand cmd11 = new SqlCommand(selectsql11, conn11);
                    cmd11.CommandType = CommandType.Text;
                    SqlDataReader sdr11;
                    sdr11 = cmd11.ExecuteReader();
                    conn11.Close();

                    string str115 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn115 = new SqlConnection(str11);
                    conn115.Open();
                    string selectsql115 = "update login set jieshu = jieshu-1 where username = '" + usid + "'";
                    SqlCommand cmd115 = new SqlCommand(selectsql115, conn115);
                    cmd115.CommandType = CommandType.Text;
                    SqlDataReader sdr115;
                    sdr115 = cmd115.ExecuteReader();
                    conn115.Close();

                    SqlConnection conn116 = new SqlConnection(str11);
                    conn116.Open();
                    string selectsql116 = "update js set flag ='已归还' where id = '" + text + "' and username='"+usid+"'";
                    SqlCommand cmd116 = new SqlCommand(selectsql116, conn116);
                    cmd116.CommandType = CommandType.Text;
                    SqlDataReader sdr116;
                    sdr116 = cmd116.ExecuteReader();
                    conn116.Close();

                    string str4 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn4 = new SqlConnection(str4);
                    conn4.Open();
                    string selectsql4 = "update fadan set flag='已处理' where id=" + bd1 + "";
                    SqlCommand cmd4 = new SqlCommand(selectsql4, conn4);
                    cmd4.CommandType = CommandType.Text;
                    SqlDataReader sdr4;
                    sdr4 = cmd4.ExecuteReader();
                    conn4.Close();

                    string str43 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn43 = new SqlConnection(str43);
                    conn43.Open();
                    string selectsql43 = "update fadan set fajin="+qian +" where id='" + bd1 + "'";
                    SqlCommand cmd43 = new SqlCommand(selectsql43, conn43);
                    cmd43.CommandType = CommandType.Text;
                    SqlDataReader sdr43;
                    sdr43 = cmd43.ExecuteReader();
                    conn43.Close();

                    string str7 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn7 = new SqlConnection(str7);
                    conn7.Open();
                    string usetime1 = DateTime.Now.ToString();
                    string selectsql7 = "insert into hs values('" + usid + "','" + text + "','" + usetime1 + "')";
                    SqlCommand cmd7 = new SqlCommand(selectsql7, conn7);
                    cmd7.CommandType = CommandType.Text;
                    SqlDataReader sdr7;
                    sdr7 = cmd7.ExecuteReader();
                    conn7.Close();
                    MessageBox.Show("用户：" + usid + " 还书成功!书号： " + text, "还书信息", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                    string str41 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn41 = new SqlConnection(str41);
                    conn41.Open();
                    string selectsql41 = "Select * from fadan where username = '" + usid + "' and flag='未处理'";
                    SqlCommand cmd41 = new SqlCommand(selectsql41, conn41);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                    cmd41.CommandType = CommandType.Text;
                    SqlDataReader sdr41;
                    sdr41 = cmd41.ExecuteReader();
                    if (sdr41.Read())//查询到借书信息
                    {
                        MessageBox.Show("用户还有违规未处理！");
                    }
                    else
                    {
                        
                        string str342 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                        SqlConnection conn342 = new SqlConnection(str342);//实例化cnn对象
                        conn342.Open();//打开
                        string selectsq342 = "update login set flag=0  where username=  '" + usid + "'";
                        SqlCommand cmd342 = new SqlCommand(selectsq342, conn342);
                        cmd342.CommandType = CommandType.Text;
                        SqlDataReader sdr342;
                        sdr342 = cmd342.ExecuteReader();
                        conn342.Close();//打开


                    }
                    conn41.Close();


                    MessageBox.Show("处理成功！\n" + p);
                    string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
                    SqlConnection conn1523 = new SqlConnection(str1523);
                    conn1523.Open();

                    SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from fadan", conn1523);
                    DataSet dds1523 = new DataSet();
                    sqlDap323.Fill(dds1523);
                    DataTable _table123 = dds1523.Tables[0];
                    int count123 = _table123.Rows.Count;
                    dataGridView1.DataSource = _table123;
                    conn1523.Close();


                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn = new SqlConnection(str);
            conn.Open();

            SqlDataAdapter sqlDap = new SqlDataAdapter("Select * from fadan where id like '%" + textBox1.Text + "%' and time like '%" + textBox2.Text + "%'  and username like '%" + textBox3.Text + "%'  and text like '%" + textBox4.Text + "%'order by id", conn);
            DataSet dds = new DataSet();
            sqlDap.Fill(dds);
            DataTable _table = dds.Tables[0];
            int count = _table.Rows.Count;
            dataGridView1.DataSource = _table;


            SqlConnection con = new SqlConnection(str);
            con.Open();

            string selectsql21 = "Select count(*) as s from fadan where id like '%" + textBox1.Text + "%' and time like '%" + textBox2.Text + "%'  and username like '%" + textBox3.Text + "%'  and text like '%" + textBox4.Text + "%'";
            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
            cmd21.CommandType = CommandType.Text;
            SqlDataReader sdr21;
            sdr21 = cmd21.ExecuteReader();
            sdr21.Read();
            int ss = Convert.ToInt32(sdr21["s"]);
            con.Close();//完成book更新
            label5.Text = "共查询到：" + ss + "条结果";

            conn.Close();
        }
    }
}
