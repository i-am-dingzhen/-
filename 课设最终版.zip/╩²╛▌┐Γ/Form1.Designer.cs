﻿namespace WindowsFormsApp2
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            图书管理系统 = new Label();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            label3 = new Label();
            label4 = new Label();
            radioButton1 = new RadioButton();
            radioButton2 = new RadioButton();
            button3 = new Button();
            SuspendLayout();
            // 
            // 图书管理系统
            // 
            图书管理系统.Location = new Point(0, 0);
            图书管理系统.Name = "图书管理系统";
            图书管理系统.Size = new Size(100, 23);
            图书管理系统.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(326, 490);
            button1.Name = "button1";
            button1.Size = new Size(129, 67);
            button1.TabIndex = 0;
            button1.Text = "登录";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(600, 490);
            button2.Name = "button2";
            button2.Size = new Size(129, 67);
            button2.TabIndex = 1;
            button2.Text = "注册";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(373, 194);
            label1.Name = "label1";
            label1.Size = new Size(86, 31);
            label1.TabIndex = 2;
            label1.Text = "账号：";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(373, 316);
            label2.Name = "label2";
            label2.Size = new Size(86, 31);
            label2.TabIndex = 3;
            label2.Text = "密码：";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(504, 188);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(151, 38);
            textBox1.TabIndex = 4;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(504, 313);
            textBox2.Name = "textBox2";
            textBox2.PasswordChar = '*';
            textBox2.Size = new Size(151, 38);
            textBox2.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(470, 104);
            label3.Name = "label3";
            label3.Size = new Size(158, 31);
            label3.TabIndex = 6;
            label3.Text = "图书管理系统";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(373, 377);
            label4.Name = "label4";
            label4.Size = new Size(86, 31);
            label4.TabIndex = 7;
            label4.Text = "密码：";
            label4.Visible = false;
            // 
            // radioButton1
            // 
            radioButton1.AutoSize = true;
            radioButton1.Location = new Point(614, 426);
            radioButton1.Name = "radioButton1";
            radioButton1.Size = new Size(117, 35);
            radioButton1.TabIndex = 8;
            radioButton1.TabStop = true;
            radioButton1.Text = "管理员";
            radioButton1.UseVisualStyleBackColor = true;
            // 
            // radioButton2
            // 
            radioButton2.AutoSize = true;
            radioButton2.Location = new Point(377, 426);
            radioButton2.Name = "radioButton2";
            radioButton2.Size = new Size(93, 35);
            radioButton2.TabIndex = 9;
            radioButton2.TabStop = true;
            radioButton2.Text = "用户";
            radioButton2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Location = new Point(461, 582);
            button3.Name = "button3";
            button3.Size = new Size(129, 67);
            button3.TabIndex = 10;
            button3.Text = "忘记密码";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form1
            // 
            ClientSize = new Size(1199, 684);
            Controls.Add(button3);
            Controls.Add(radioButton2);
            Controls.Add(radioButton1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label 图书管理系统;
        private Button button1;
        private Button button2;
        private Label label1;
        private Label label2;
        private TextBox textBox1;
        private TextBox textBox2;
        private Label label3;
        private Label label4;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private Button button3;
    }

}

