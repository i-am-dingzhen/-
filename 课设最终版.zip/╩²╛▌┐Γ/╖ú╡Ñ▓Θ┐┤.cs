﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 罚单查看 : Form
    {
        string yh = WindowsFormsApp2.Form1.msg;
        public 罚单查看()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from fadan where username='"+yh+"'", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }

        private void 返回_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
