﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 图书馆系统
{
    public partial class 图书管理 : Form
    {
        public 图书管理()
        {
            InitializeComponent();
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from book", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }

        private void fun()
        {
            string str1523 = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
            SqlConnection conn1523 = new SqlConnection(str1523);
            conn1523.Open();

            SqlDataAdapter sqlDap323 = new SqlDataAdapter("Select * from book", conn1523);
            DataSet dds1523 = new DataSet();
            sqlDap323.Fill(dds1523);
            DataTable _table123 = dds1523.Tables[0];
            int count123 = _table123.Rows.Count;
            dataGridView1.DataSource = _table123;
            conn1523.Close();
        }
        string str = @"Data Source=MYBUGRUNNINGFAS;Initial catalog=LoginTable;integrated Security=True";
        private void 查询_Click(object sender, EventArgs e)
        {
            
            SqlConnection conn = new SqlConnection(str);
            conn.Open();

            SqlDataAdapter sqlDap = new SqlDataAdapter("Select * from book where id like '%" + textBox1.Text + "%' and bname like '%" + textBox2.Text + "%'  and btype like '%" + textBox3.Text + "%'  and cb like '%" + textBox4.Text + "%'order by id", conn);
            DataSet dds = new DataSet();
            sqlDap.Fill(dds);
            DataTable _table = dds.Tables[0];
            int count = _table.Rows.Count;
            dataGridView1.DataSource = _table;
            conn.Close();


        }
        private bool fun1(string a)
        {
            if (a == "") return false;
            SqlConnection conn1 = new SqlConnection(str);//实例化sql连接对象
            conn1.Open();
            //写sqlserver语句
            string selectsql1 = "select * from book where id ='"+a+"'";
            SqlCommand cmd1 = new SqlCommand(selectsql1, conn1);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
            cmd1.CommandType = CommandType.Text;
            SqlDataReader sdr1;//声明对象 
            sdr1 = cmd1.ExecuteReader();
            if (sdr1.Read())
            {
                conn1.Close();
                return true;
            }
            else
            {
                conn1.Close();
                return false;
            }

        }
        private void button1_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认添加吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {

                if (textBox8.Text!="" && textBox7.Text != "" && textBox6.Text != "" && textBox5.Text != "" && textBox9.Text != ""  )
                {
                    int mid = 0;
                    bool vis = true;
                    try
                    {
                        mid = Convert.ToInt32(textBox9.Text);
                    }
                    catch (Exception ex)
                    {
                       
                        vis = false;
                    }
                    if (vis == true)
                    {
                        SqlConnection conn15 = new SqlConnection(str);//实例化sql连接对象
                        conn15.Open();
                        //写sqlserver语句
                        string selectsql15 = "select * from book where id ='" + textBox8.Text + "'";
                        SqlCommand cmd15 = new SqlCommand(selectsql15, conn15);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                        cmd15.CommandType = CommandType.Text;
                        SqlDataReader sdr15;//声明对象 
                        sdr15 = cmd15.ExecuteReader();
                        if (sdr15.Read())
                        {
                            MessageBox.Show("编号重复！");
                        }

                        else
                        {
                            SqlConnection conn1 = new SqlConnection(str);//实例化sql连接对象
                            conn1.Open();
                            //写sqlserver语句
                            string selectsql1 = "insert into book  values ('" + textBox8.Text + "','" + textBox7.Text + "','" + textBox9.Text + "','" + textBox5.Text + "','" + textBox6.Text + "','" + textBox9.Text + "')";
                            SqlCommand cmd1 = new SqlCommand(selectsql1, conn1);//SqlCommand对象允许你指定在数据库上执行的操作的类型。
                            cmd1.CommandType = CommandType.Text;
                            SqlDataReader sdr1;//声明对象 
                            sdr1 = cmd1.ExecuteReader();  //读cmd取到的text文本
                            conn1.Close();
                            MessageBox.Show("添加成功！");
                            fun();
                        }

                        conn15.Close();
                    }
                    else
                    {
                        MessageBox.Show("数量请输入数字！");
                    }
                }
                else
                {
                    MessageBox.Show("信息不全！");
                }


                
            }
            else
            {
                f2.Close();
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (fun1(textBox10.Text))
                {
                    SqlConnection con = new SqlConnection(str);
                    con.Open();

                    string selectsql21 = "update book set bname  = '" + textBox11.Text + "' where id = '" + textBox10.Text + "'";
                    SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                    cmd21.CommandType = CommandType.Text;
                    SqlDataReader sdr21;
                    sdr21 = cmd21.ExecuteReader();
                    con.Close();
                    fun();
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    MessageBox.Show("图书不存在");
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (fun1(textBox13.Text))
                {
                    SqlConnection con = new SqlConnection(str);
                    con.Open();

                    string selectsql21 = "update book set btype  = '" + textBox12.Text + "' where id = '" + textBox13.Text + "'";
                    SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                    cmd21.CommandType = CommandType.Text;
                    SqlDataReader sdr21;
                    sdr21 = cmd21.ExecuteReader();
                    con.Close();
                    fun();
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    MessageBox.Show("图书不存在");
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (fun1(textBox15.Text))
                {
                    SqlConnection con = new SqlConnection(str);
                    con.Open();

                    string selectsql21 = "update book set btype  =' " + textBox14.Text + "'where id = '" + textBox15.Text + "'";
                    SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                    cmd21.CommandType = CommandType.Text;
                    SqlDataReader sdr21;
                    sdr21 = cmd21.ExecuteReader();
                    con.Close();
                    fun();
                    MessageBox.Show("修改成功！");
                }
                else
                {
                    MessageBox.Show("图书不存在");
                }
            }
            else
            {
                f2.Close();
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认修改吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (fun1(textBox17.Text))
                {
                    int mid = 0;
                    bool vis = true;
                    try
                    {
                        mid = Convert.ToInt32(textBox16.Text);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("请输入数字");
                        vis = false;
                    }




                    if (vis == true)

                    {
                        SqlConnection con1 = new SqlConnection(str);
                        con1.Open();

                        string selectsql211 = "select * from book  where id   = '" + textBox17.Text + "'";
                        SqlCommand cmd211 = new SqlCommand(selectsql211, con1);
                        cmd211.CommandType = CommandType.Text;
                        SqlDataReader sdr211;
                        sdr211 = cmd211.ExecuteReader();
                        sdr211.Read();
                        int nn = Convert.ToInt32(sdr211["nnum"]);
                        if (nn + mid >= 0)
                        {

                            SqlConnection con = new SqlConnection(str);
                            con.Open();

                            string selectsql21 = "update book set bnum  = bnum+" + mid  + " where id = '" + textBox17.Text + "'";
                            SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                            cmd21.CommandType = CommandType.Text;
                            SqlDataReader sdr21;
                            sdr21 = cmd21.ExecuteReader();
                            con.Close();
            

                            SqlConnection con8 = new SqlConnection(str);
                            con8.Open();

                            string selectsql218 = "update book set nnum  = nnum+" + mid + " where id = '" + textBox17.Text + "'";
                            SqlCommand cmd218 = new SqlCommand(selectsql218, con8);
                            cmd218.CommandType = CommandType.Text;
                            SqlDataReader sdr218;
                            sdr218 = cmd218.ExecuteReader();
                            con8.Close();
                            fun();

                            MessageBox.Show("修改成功！");

                        }

                        else
                        {
                            MessageBox.Show("库存不足");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("图书不存在");
                }

            }
            else
            {
                f2.Close();
            }
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            确认 f2 = new 确认();
            string mid3 = "确认删除吗？";
            f2.label1.Text = mid3;
            if (f2.ShowDialog() == DialogResult.OK)
            {
                if (fun1(textBox19.Text))
                {
                    SqlConnection con = new SqlConnection(str);
                    con.Open();

                    string selectsql21 = "delete from book   where id = '" + textBox19.Text + "'";
                    SqlCommand cmd21 = new SqlCommand(selectsql21, con);
                    cmd21.CommandType = CommandType.Text;
                    SqlDataReader sdr21;
                    sdr21 = cmd21.ExecuteReader();
                    con.Close();
                    fun();
                    MessageBox.Show("删除成功！");
                }
                else
                {
                    MessageBox.Show("图书不存在");
                }
            }
            else
            {
                f2.Close();
            }
        }
    }
}
